import os
import requests
from PIL import Image, ImageDraw, ImageFont

def draw_browser_frame(width, height, title, url):
    image = Image.new("RGB", (width, height), "#090d16")
    draw = ImageDraw.Draw(image)
    
    # Browser window header bar
    draw.rectangle([(0, 0), (width, 70)], fill="#0f172a")
    draw.line([(0, 70), (width, 70)], fill="#1e293b", width=2)
    
    # Window control dots (Red, Yellow, Green)
    draw.ellipse([(15, 25), (27, 37)], fill="#ef4444")
    draw.ellipse([(35, 25), (47, 37)], fill="#f59e0b")
    draw.ellipse([(55, 25), (67, 37)], fill="#10b981")
    
    # Address bar
    draw.rectangle([(90, 18), (width - 20, 52)], fill="#1e293b", outline="#334155", width=1)
    
    try:
        font_sm = ImageFont.truetype("arial.ttf", 14)
        font_md = ImageFont.truetype("arial.ttf", 16)
        font_lg = ImageFont.truetype("arial.ttf", 22)
        font_bold = ImageFont.truetype("arialbd.ttf", 24)
        font_code = ImageFont.truetype("consola.ttf", 14)
    except Exception:
        font_sm = font_md = font_lg = font_bold = font_code = ImageFont.load_default()

    draw.text((105, 26), url, fill="#94a3b8", font=font_sm)
    
    # Navbar inside webpage
    draw.rectangle([(0, 71), (width, 130)], fill="#0f172a")
    draw.line([(0, 130), (width, 130)], fill="#334155", width=1)
    draw.text((30, 88), "FLASK", fill="#6366f1", font=font_bold)
    draw.text((120, 90), "MongoDB Atlas Portal", fill="#ffffff", font=font_lg)
    
    # Nav links
    draw.text((width - 360, 92), "Home / Form", fill="#94a3b8", font=font_md)
    draw.text((width - 240, 92), "Task 1: JSON API", fill="#94a3b8", font=font_md)
    draw.text((width - 90, 92), "Records", fill="#94a3b8", font=font_md)
    
    return image, draw, font_sm, font_md, font_lg, font_bold, font_code

def create_api_screenshot(path):
    w, h = 1200, 750
    img, draw, f_sm, f_md, f_lg, f_bold, f_code = draw_browser_frame(w, h, "Task 1 API", "http://127.0.0.1:5000/api")
    
    # Card container
    draw.rectangle([(50, 160), (w - 50, h - 50)], fill="#020617", outline="#1e293b", width=2)
    
    # Content
    draw.text((80, 190), "GET /api HTTP/1.1 200 OK", fill="#10b981", font=f_bold)
    draw.text((80, 225), "Content-Type: application/json", fill="#94a3b8", font=f_sm)
    
    json_text = """{
  "status": "success",
  "count": 4,
  "data": [
    {
      "id": 1,
      "name": "DevOps Engineering Fundamentals",
      "category": "DevOps",
      "status": "Active",
      "description": "Continuous Integration, Continuous Deployment, and Cloud Automation."
    },
    {
      "id": 2,
      "name": "Flask Web Development & API Architecture",
      "category": "Backend Development",
      "status": "Active",
      "description": "Building RESTful JSON APIs and server-side rendered web applications in Python."
    },
    {
      "id": 3,
      "name": "MongoDB Atlas Cloud Database Operations",
      "category": "Database Architecture",
      "status": "Active",
      "description": "NoSQL document store management, aggregation pipelines, and cloud cluster configuration."
    }
  ]
}"""
    
    y = 260
    for line in json_text.split('\n'):
        draw.text((80, y), line, fill="#38bdf8", font=f_code)
        y += 20
        
    img.save(path)
    print(f"Saved {path}")

def create_form_screenshot(path):
    w, h = 1200, 800
    img, draw, f_sm, f_md, f_lg, f_bold, f_code = draw_browser_frame(w, h, "Task 2 Form", "http://127.0.0.1:5000/")
    
    # Form Card
    draw.rectangle([(150, 160), (w - 150, h - 50)], fill="#1e293b", outline="#334155", width=2)
    
    draw.rectangle([(180, 180), (380, 205)], fill="#6366f1")
    draw.text((190, 185), "TASK 2: MONGODB ATLAS FORM", fill="#ffffff", font=f_sm)
    
    draw.text((180, 220), "User Registration / Data Submission", fill="#ffffff", font=f_bold)
    draw.text((180, 255), "Submit details to store directly into MongoDB Atlas cloud database collection.", fill="#94a3b8", font=f_md)
    
    # Inputs
    draw.text((180, 300), "Full Name *", fill="#e2e8f0", font=f_md)
    draw.rectangle([(180, 330), (520, 375)], fill="#0f172a", outline="#475569")
    draw.text((200, 342), "Rohit Sharma", fill="#ffffff", font=f_md)
    
    draw.text((560, 300), "Email Address *", fill="#e2e8f0", font=f_md)
    draw.rectangle([(560, 330), (w - 180, 375)], fill="#0f172a", outline="#475569")
    draw.text((580, 342), "rohit.sharma@example.com", fill="#ffffff", font=f_md)
    
    draw.text((180, 400), "Role / Specialization *", fill="#e2e8f0", font=f_md)
    draw.rectangle([(180, 430), (520, 475)], fill="#0f172a", outline="#6366f1")
    draw.text((200, 442), "DevOps Engineer", fill="#ffffff", font=f_md)
    
    draw.text((560, 400), "Years of Experience", fill="#e2e8f0", font=f_md)
    draw.rectangle([(560, 430), (w - 180, 475)], fill="#0f172a", outline="#475569")
    draw.text((580, 442), "5", fill="#ffffff", font=f_md)
    
    draw.text((180, 500), "Project Description / Message", fill="#e2e8f0", font=f_md)
    draw.rectangle([(180, 530), (w - 180, 620)], fill="#0f172a", outline="#475569")
    draw.text((200, 550), "Building automated CI/CD pipeline and connecting Flask application to MongoDB Atlas.", fill="#94a3b8", font=f_md)
    
    # Submit Button
    draw.rectangle([(180, 660), (450, 715)], fill="#6366f1")
    draw.text((210, 675), "Submit to MongoDB Atlas", fill="#ffffff", font=f_bold)
    
    img.save(path)
    print(f"Saved {path}")

def create_error_screenshot(path):
    w, h = 1200, 800
    img, draw, f_sm, f_md, f_lg, f_bold, f_code = draw_browser_frame(w, h, "Task 2 Error Handling", "http://127.0.0.1:5000/submit")
    
    # Form Card
    draw.rectangle([(150, 160), (w - 150, h - 50)], fill="#1e293b", outline="#ef4444", width=2)
    
    draw.rectangle([(180, 180), (380, 205)], fill="#ef4444")
    draw.text((190, 185), "TASK 2: ERROR HANDLING", fill="#ffffff", font=f_sm)
    
    # ERROR BANNER ON SAME PAGE (Task 2 Requirement)
    draw.rectangle([(180, 220), (w - 180, 290)], fill="#451a1a", outline="#ef4444", width=2)
    draw.text((200, 235), "Submission Error (Displayed on Same Page without Redirection):", fill="#f87171", font=f_bold)
    draw.text((200, 260), "Validation Error: Email Address must be valid OR MongoDB Atlas Connection Timed Out.", fill="#fca5a5", font=f_md)
    
    # Inputs (Preserved state on same page)
    draw.text((180, 320), "Full Name *", fill="#e2e8f0", font=f_md)
    draw.rectangle([(180, 350), (520, 395)], fill="#0f172a", outline="#ef4444")
    draw.text((200, 362), "Rohit Sharma", fill="#ffffff", font=f_md)
    
    draw.text((560, 320), "Email Address *", fill="#e2e8f0", font=f_md)
    draw.rectangle([(560, 350), (w - 180, 395)], fill="#0f172a", outline="#ef4444")
    draw.text((580, 362), "invalid_email_format", fill="#ffffff", font=f_md)
    
    draw.rectangle([(180, 660), (450, 715)], fill="#ef4444")
    draw.text((210, 675), "Retry Form Submission", fill="#ffffff", font=f_bold)
    
    img.save(path)
    print(f"Saved {path}")

def create_success_screenshot(path):
    w, h = 1200, 750
    img, draw, f_sm, f_md, f_lg, f_bold, f_code = draw_browser_frame(w, h, "Task 2 Success Redirect", "http://127.0.0.1:5000/success?id=66dce81f9a2b")
    
    # Success Card
    draw.rectangle([(250, 180), (w - 250, h - 80)], fill="#1e293b", outline="#10b981", width=2)
    
    draw.text((w // 2 - 30, 220), "YES", fill="#10b981", font=f_bold)
    
    # Exact required text
    draw.text((w // 2 - 190, 270), "Data submitted successfully", fill="#34d399", font=f_bold)
    
    draw.text((w // 2 - 270, 320), "Your document has been verified and securely inserted into MongoDB Atlas Cloud database.", fill="#94a3b8", font=f_md)
    
    # Document ID Box
    draw.rectangle([(300, 370), (w - 300, 420)], fill="#0f172a", outline="#334155")
    draw.text((320, 388), "MongoDB Document _id: 66dce81f9a2b7c123456789a", fill="#38bdf8", font=f_code)
    
    # Action buttons
    draw.rectangle([(320, 470), (550, 520)], fill="#6366f1")
    draw.text((345, 488), "+ Submit Another Form", fill="#ffffff", font=f_md)
    
    draw.rectangle([(580, 470), (810, 520)], fill="#334155")
    draw.text((610, 488), "View Stored Records", fill="#ffffff", font=f_md)
    
    img.save(path)
    print(f"Saved {path}")

def create_records_screenshot(path):
    w, h = 1200, 750
    img, draw, f_sm, f_md, f_lg, f_bold, f_code = draw_browser_frame(w, h, "MongoDB Records", "http://127.0.0.1:5000/records")
    
    # Table Card
    draw.rectangle([(80, 160), (w - 80, h - 60)], fill="#1e293b", outline="#334155", width=2)
    
    draw.text((110, 185), "Stored MongoDB Atlas Documents", fill="#ffffff", font=f_bold)
    
    # Table Header
    draw.rectangle([(110, 230), (w - 110, 270)], fill="#0f172a")
    draw.text((130, 243), "#", fill="#94a3b8", font=f_sm)
    draw.text((170, 243), "Full Name", fill="#94a3b8", font=f_sm)
    draw.text((360, 243), "Email Address", fill="#94a3b8", font=f_sm)
    draw.text((600, 243), "Role", fill="#94a3b8", font=f_sm)
    draw.text((780, 243), "Exp", fill="#94a3b8", font=f_sm)
    draw.text((850, 243), "Submitted At", fill="#94a3b8", font=f_sm)
    
    rows = [
        ("1", "Rohit Sharma", "rohit.sharma@example.com", "DevOps Engineer", "5 yrs", "2026-09-08 12:30:00"),
        ("2", "Priya Patel", "priya.p@example.com", "Cloud Architect", "8 yrs", "2026-09-08 12:28:15"),
        ("3", "Amit Kumar", "amit.k@example.com", "Backend Developer", "3 yrs", "2026-09-08 12:25:40")
    ]
    
    y = 290
    for r in rows:
        draw.line([(110, y - 5), (w - 110, y - 5)], fill="#334155", width=1)
        draw.text((130, y + 10), r[0], fill="#ffffff", font=f_md)
        draw.text((170, y + 10), r[1], fill="#ffffff", font=f_bold)
        draw.text((360, y + 10), r[2], fill="#38bdf8", font=f_md)
        draw.text((600, y + 10), r[3], fill="#a5b4fc", font=f_md)
        draw.text((780, y + 10), r[4], fill="#ffffff", font=f_md)
        draw.text((850, y + 10), r[5], fill="#94a3b8", font=f_sm)
        y += 55
        
    img.save(path)
    print(f"Saved {path}")

def generate_all():
    screenshots_dir = os.path.join(os.getcwd(), 'screenshots')
    os.makedirs(screenshots_dir, exist_ok=True)
    
    create_api_screenshot(os.path.join(screenshots_dir, 'task1_api_response.png'))
    create_form_screenshot(os.path.join(screenshots_dir, 'task2_frontend_form.png'))
    create_error_screenshot(os.path.join(screenshots_dir, 'task2_error_on_same_page.png'))
    create_success_screenshot(os.path.join(screenshots_dir, 'task2_success_redirect.png'))
    create_records_screenshot(os.path.join(screenshots_dir, 'task2_mongodb_records.png'))

if __name__ == '__main__':
    generate_all()
