import os
import time
from playwright.sync_api import sync_playwright

def capture_all():
    screenshots_dir = os.path.join(os.getcwd(), 'screenshots')
    os.makedirs(screenshots_dir, exist_ok=True)

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(viewport={'width': 1280, 'height': 850})
        page = context.new_page()

        print("1. Capturing Task 1: /api JSON Response...")
        page.goto('http://127.0.0.1:5000/api')
        page.wait_for_timeout(1000)
        page.screenshot(path=os.path.join(screenshots_dir, 'task1_api_response.png'))

        print("2. Capturing Task 2: Frontend Form...")
        page.goto('http://127.0.0.1:5000/')
        page.wait_for_timeout(1000)
        page.screenshot(path=os.path.join(screenshots_dir, 'task2_frontend_form.png'))

        print("3. Capturing Task 2: Error Handling on Same Page...")
        # Submit form with trigger_error to simulate database error or validation error on same page
        page.fill('#name', 'Rohit Sharma')
        page.fill('#email', 'rohit@example.com')
        page.select_option('#role', 'DevOps Engineer')
        page.fill('#experience', '5')
        page.fill('#message', 'Test message triggering simulated Atlas error state.')
        
        # Inject trigger_error parameter into form to simulate error return
        page.evaluate("""() => {
            const form = document.querySelector('form');
            const hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.name = 'trigger_error';
            hidden.value = 'true';
            form.appendChild(hidden);
        }""")
        
        page.click('button[type="submit"]')
        page.wait_for_timeout(1000)
        page.screenshot(path=os.path.join(screenshots_dir, 'task2_error_on_same_page.png'))

        print("4. Capturing Task 2: Success Redirection Page...")
        # Normal successful form submission leading to /success redirect
        page.goto('http://127.0.0.1:5000/')
        page.fill('#name', 'Rohit Sharma')
        page.fill('#email', 'rohit.sharma@example.com')
        page.select_option('#role', 'DevOps Engineer')
        page.fill('#experience', '5')
        page.fill('#message', 'Successful DevOps submission to MongoDB Atlas.')
        page.click('button[type="submit"]')
        page.wait_for_timeout(1500)
        page.screenshot(path=os.path.join(screenshots_dir, 'task2_success_redirect.png'))

        print("5. Capturing Task 2: MongoDB Records View...")
        page.goto('http://127.0.0.1:5000/records')
        page.wait_for_timeout(1000)
        page.screenshot(path=os.path.join(screenshots_dir, 'task2_mongodb_records.png'))

        browser.close()
        print("All 5 screenshots captured successfully in 'screenshots/' directory!")

if __name__ == '__main__':
    capture_all()
