# Flask and MongoDB Atlas Application

**Student Name:** Rohit  
**Folder Name:** `Flask_and_MongoDB_Rohit`  
**GitHub Repository:** [https://github.com/Rohit00071/TuteDude_assignmet](https://github.com/Rohit00071/TuteDude_assignmet)

---

## Project Overview

This project is a Flask web application built to fulfill the assignment objectives:
1. **Task 1: JSON API Route (`/api`)**
   - Returns a JSON list read from a backend file (`data/backend_data.json`).
2. **Task 2: Frontend Form with MongoDB Atlas**
   - Renders a user submission form on the frontend (`/`).
   - Inserts submitted data into MongoDB Atlas cloud database collection.
   - **On Success:** Redirects to `/success` displaying **“Data submitted successfully”**.
   - **On Error:** Displays the error message directly on the **same page** without redirection.

---

## Directory Structure

```
Flask_and_MongoDB_Rohit/
├── app.py                      # Core Flask backend server
├── requirements.txt            # Python dependencies
├── .env                        # Environment configuration
├── .env.example                # Example environment template
├── README.md                   # Documentation & setup instructions
├── Flask_and_MongoDB_Documentation.docx # Final submission document with screenshots
├── data/
│   └── backend_data.json       # Backend file containing JSON list for Task 1
├── templates/
│   ├── index.html              # Task 2 submission form with inline error alert
│   ├── success.html            # Task 2 success page after redirection
│   └── records.html            # Stored MongoDB documents viewer
└── static/
    └── css/
        └── style.css           # Modern glassmorphism UI styling
```

---

## How to Run the Application

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure MongoDB Atlas URI
Update `.env` with your active MongoDB Atlas connection string:
```env
MONGO_URI=mongodb+srv://<username>:<password>@cluster0.mongodb.net/flask_mongodb_app?retryWrites=true&w=majority
```

### 3. Run Flask Development Server
```bash
python app.py
```

### 4. Test Routes
- **Task 1 JSON API Route:** `http://127.0.0.1:5000/api`
- **Task 2 Frontend Form:** `http://127.0.0.1:5000/`
- **Task 2 Success Redirection:** `http://127.0.0.1:5000/success`
- **MongoDB Records List:** `http://127.0.0.1:5000/records`

---

## Task Verification & Submission Guidelines Compliance

- **Complete Source Code**: All files are included in `Flask_and_MongoDB_Rohit`.
- **Documentation**: Includes `Flask_and_MongoDB_Documentation.docx` with detailed screenshots, terminal logs, and route explanations.
- **Archive**: Compressed into `Flask_and_MongoDB_Rohit.zip` for final portal upload.
- **GitHub Link**: [https://github.com/Rohit00071/TuteDude_assignmet](https://github.com/Rohit00071/TuteDude_assignmet)
