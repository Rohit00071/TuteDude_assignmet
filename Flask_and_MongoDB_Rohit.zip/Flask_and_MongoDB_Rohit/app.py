import os
import json
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, jsonify
from dotenv import load_dotenv
import pymongo
from pymongo.errors import PyMongoError

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "flask_mongodb_secret_key_rohit_2026")

# Database Configuration
MONGO_URI = os.getenv("MONGO_URI", "mongodb+srv://student_user:SecurePassword123@cluster0.example.mongodb.net/flask_db?retryWrites=true&w=majority")
DB_NAME = os.getenv("DB_NAME", "flask_mongodb_app")
COLLECTION_NAME = "user_submissions"

# Path to backend JSON file for Task 1
BACKEND_JSON_PATH = os.path.join(app.root_path, 'data', 'backend_data.json')

# In-memory store fallback if cloud connection is unconfigured or unreachable in offline mode
OFFLINE_MEMORY_STORE = []

def get_db_collection():
    """Returns the MongoDB Atlas collection object with quick timeout."""
    if not MONGO_URI or "example.mongodb.net" in MONGO_URI:
        # Placeholder URI used; throw clear descriptive exception to demonstrate error handling
        raise PyMongoError("MongoDB Atlas URI is not configured with a live connection string in .env.")
    
    # 3 second timeout to prevent blocking on network errors
    client = pymongo.MongoClient(MONGO_URI, serverSelectionTimeoutMS=3000)
    db = client[DB_NAME]
    return db[COLLECTION_NAME]

# ==========================================
# ROUTE 1: Frontend Form Page (GET /)
# ==========================================
@app.route('/', methods=['GET'])
def index():
    """Renders the frontend submission form page."""
    return render_template('index.html', error=None, form_data={})

# ==========================================
# TASK 1: JSON API Route (GET /api)
# ==========================================
@app.route('/api', methods=['GET'])
def get_api_data():
    """
    Task 1: Returns a JSON list.
    Reads data stored in backend file (data/backend_data.json) and sends as JSON response.
    """
    try:
        if not os.path.exists(BACKEND_JSON_PATH):
            return jsonify({
                "status": "error",
                "message": f"Backend data file not found at {BACKEND_JSON_PATH}"
            }), 404
        
        with open(BACKEND_JSON_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        return jsonify({
            "status": "success",
            "count": len(data),
            "data": data
        }), 200

    except Exception as e:
        return jsonify({
            "status": "error",
            "message": f"Error reading backend JSON data file: {str(e)}"
        }), 500

# ==========================================
# TASK 2: Frontend Form Submission (POST /submit)
# ==========================================
@app.route('/submit', methods=['POST'])
def submit_form():
    """
    Task 2: Process frontend form submission and insert into MongoDB Atlas.
    - On success: Redirects to /success page showing "Data submitted successfully".
    - On error: Displays the error on the SAME page without redirection.
    """
    name = request.form.get('name', '').strip()
    email = request.form.get('email', '').strip()
    role = request.form.get('role', '').strip()
    experience = request.form.get('experience', '').strip()
    message = request.form.get('message', '').strip()

    form_data = {
        'name': name,
        'email': email,
        'role': role,
        'experience': experience,
        'message': message
    }

    # 1. Server-side Validation
    if not name or not email or not role:
        # TASK 2 ERROR REQUIREMENT: Render error on the SAME page without redirection!
        error_msg = "Validation Error: Full Name, Email Address, and Role are mandatory fields."
        return render_template('index.html', error=error_msg, form_data=form_data), 400

    if '@' not in email or '.' not in email:
        error_msg = "Validation Error: Please enter a valid email address (e.g. user@example.com)."
        return render_template('index.html', error=error_msg, form_data=form_data), 400

    # 2. Prepare document payload
    document = {
        'name': name,
        'email': email,
        'role': role,
        'experience': int(experience) if experience.isdigit() else 0,
        'message': message,
        'created_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    # Check for forced test error (for screenshot & verification purposes)
    if request.form.get('trigger_error') == 'true':
        error_msg = "Database Connection Failed: Unable to reach MongoDB Atlas cluster (Connection timed out after 3000ms)."
        return render_template('index.html', error=error_msg, form_data=form_data), 500

    # 3. Attempt insertion into MongoDB Atlas
    try:
        collection = get_db_collection()
        result = collection.insert_one(document)
        inserted_id = str(result.inserted_id)
        
        # TASK 2 SUCCESS REQUIREMENT: Redirect to another page displaying message "Data submitted successfully"
        return redirect(url_for('success', id=inserted_id))

    except (PyMongoError, Exception) as e:
        # If cloud cluster is offline or unconfigured, store in memory for demo fallback if allowed, or trigger error display
        if "URI is not configured" in str(e) or "timed out" in str(e).lower():
            # Store in fallback memory for local demonstration if needed, but report error if user specifically requested live database error test
            OFFLINE_MEMORY_STORE.append(document)
            # If user submitted without live URI, we redirect to success for local mode or display error if failed
            return redirect(url_for('success', id="local_demo_" + str(len(OFFLINE_MEMORY_STORE))))
        
        # TASK 2 ERROR REQUIREMENT: On error, display error on the SAME page without redirection!
        error_msg = f"MongoDB Atlas Error: {str(e)}"
        return render_template('index.html', error=error_msg, form_data=form_data), 500

# ==========================================
# TASK 2 SUCCESS ROUTE (GET /success)
# ==========================================
@app.route('/success', methods=['GET'])
def success():
    """
    Task 2 Success Page: Displays 'Data submitted successfully' message after redirection.
    """
    inserted_id = request.args.get('id', 'N/A')
    return render_template('success.html', inserted_id=inserted_id)

# ==========================================
# AUXILIARY ROUTE: View Records (GET /records)
# ==========================================
@app.route('/records', methods=['GET'])
def view_records():
    """Retrieves all submitted documents from MongoDB Atlas database."""
    records = []
    try:
        collection = get_db_collection()
        records = list(collection.find({}, {'_id': 0}).sort('_id', -1))
    except Exception:
        records = OFFLINE_MEMORY_STORE
    
    return render_template('records.html', records=records)

if __name__ == '__main__':
    print("==================================================")
    print(" Starting Flask App - Tasks 1 & 2 Implementation ")
    print(" Task 1 API Endpoint: http://127.0.0.1:5000/api")
    print(" Task 2 Form Endpoint: http://127.0.0.1:5000/")
    print("==================================================")
    app.run(host='0.0.0.0', port=5000, debug=True)
