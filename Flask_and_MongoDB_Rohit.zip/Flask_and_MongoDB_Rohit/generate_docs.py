import os
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import parse_xml, OxmlElement
from docx.oxml.ns import nsdecls, qn

def add_heading_styled(doc, text, level):
    p = doc.add_heading(text, level=level)
    p.paragraph_format.space_before = Pt(14)
    p.paragraph_format.space_after = Pt(6)
    run = p.runs[0]
    if level == 1:
        run.font.color.rgb = RGBColor(99, 102, 241) # Indigo primary
        run.font.size = Pt(18)
        run.font.bold = True
    elif level == 2:
        run.font.color.rgb = RGBColor(139, 92, 246) # Purple secondary
        run.font.size = Pt(14)
        run.font.bold = True
    elif level == 3:
        run.font.color.rgb = RGBColor(30, 41, 59)
        run.font.size = Pt(12)
        run.font.bold = True
    return p

def add_code_block(doc, code_text):
    tbl = doc.add_table(rows=1, cols=1)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = tbl.cell(0, 0)
    
    # Set cell background to light grey/slate
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="F1F5F9"/>')
    cell._tc.get_or_add_tcPr().append(shd)
    
    # Set thin border
    tcBorders = parse_xml(f'<w:tcBorders {nsdecls("w")}><w:top w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/><w:left w:val="single" w:sz="12" w:space="0" w:color="6366F1"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/><w:right w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/></w:tcBorders>')
    cell._tc.get_or_add_tcPr().append(tcBorders)

    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.15
    run = p.add_run(code_text)
    run.font.name = 'Consolas'
    run.font.size = Pt(9.5)
    run.font.color.rgb = RGBColor(15, 23, 42)

def add_image_safe(doc, image_path, caption, width=Inches(6.0)):
    if os.path.exists(image_path):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = Pt(10)
        p.paragraph_format.space_after = Pt(4)
        run = p.add_run()
        run.add_picture(image_path, width=width)
        
        # Caption
        cp = doc.add_paragraph()
        cp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        cp.paragraph_format.space_after = Pt(14)
        crun = cp.add_run(f"Figure: {caption}")
        crun.font.size = Pt(9)
        crun.font.italic = True
        crun.font.color.rgb = RGBColor(100, 116, 139)
    else:
        doc.add_paragraph(f"[Screenshot Placeholder: {caption} - File {image_path} not found]")

def build_docx():
    doc = docx.Document()
    
    # Set page margins
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(0.8)
        section.bottom_margin = Inches(0.8)
        section.left_margin = Inches(0.8)
        section.right_margin = Inches(0.8)

    # Document Header / Title Card
    title_p = doc.add_paragraph()
    title_p.paragraph_format.space_before = Pt(10)
    title_p.paragraph_format.space_after = Pt(2)
    title_run = title_p.add_run("Flask Web Application with MongoDB Atlas")
    title_run.font.size = Pt(24)
    title_run.font.bold = True
    title_run.font.color.rgb = RGBColor(99, 102, 241)

    sub_p = doc.add_paragraph()
    sub_p.paragraph_format.space_after = Pt(14)
    sub_run = sub_p.add_run("Project Documentation & Verification Report | Tasks 1 & 2")
    sub_run.font.size = Pt(14)
    sub_run.font.color.rgb = RGBColor(100, 116, 139)

    # Metadata Table
    meta_tbl = doc.add_table(rows=4, cols=2)
    meta_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    meta_data = [
        ("Student Name:", "Rohit"),
        ("Submission Directory:", "Flask_and_MongoDB_Rohit"),
        ("GitHub Repository:", "https://github.com/Rohit00071/TuteDude_assignmet"),
        ("Technologies Used:", "Python 3.14, Flask 3.1.3, PyMongo, MongoDB Atlas, HTML5/CSS3")
    ]
    for idx, (label, val) in enumerate(meta_data):
        row = meta_tbl.rows[idx]
        cell_lbl, cell_val = row.cells[0], row.cells[1]
        
        shd1 = parse_xml(f'<w:shd {nsdecls("w")} w:fill="EEF2FF"/>')
        shd2 = parse_xml(f'<w:shd {nsdecls("w")} w:fill="F8FAFC"/>')
        cell_lbl._tc.get_or_add_tcPr().append(shd1)
        cell_val._tc.get_or_add_tcPr().append(shd2)

        p1 = cell_lbl.paragraphs[0]
        p1.paragraph_format.space_before = Pt(3)
        p1.paragraph_format.space_after = Pt(3)
        r1 = p1.add_run(label)
        r1.bold = True
        r1.font.size = Pt(10)
        r1.font.color.rgb = RGBColor(67, 56, 202)

        p2 = cell_val.paragraphs[0]
        p2.paragraph_format.space_before = Pt(3)
        p2.paragraph_format.space_after = Pt(3)
        r2 = p2.add_run(val)
        r2.font.size = Pt(10)
        r2.font.color.rgb = RGBColor(15, 23, 42)

    doc.add_paragraph().paragraph_format.space_after = Pt(10)

    # Section 1: Objective & Summary
    add_heading_styled(doc, "1. Objective & Project Overview", level=1)
    p = doc.add_paragraph()
    p.add_run("The objective of this assignment is to develop a complete Flask web application integrating a local file-backed JSON API route (Task 1) and a frontend submission form connected to MongoDB Atlas Cloud Database with robust success and error handling mechanisms (Task 2).")
    
    doc.add_paragraph().paragraph_format.space_after = Pt(4)

    # Section 2: Task 1 - JSON API Route
    add_heading_styled(doc, "2. Task 1: JSON API Route (/api)", level=1)
    doc.add_paragraph("Requirement: Create a Flask application with an /api route. When accessed, it should return a JSON list read from a backend file.")

    add_heading_styled(doc, "Implementation Details", level=2)
    doc.add_paragraph("A backend JSON data file was created at `data/backend_data.json` containing structured records. The Flask route reads this file asynchronously upon receiving a GET request and serves standard JSON responses.")

    doc.add_paragraph("Backend JSON Data File (`data/backend_data.json`):")
    add_code_block(doc, """[
  {
    "id": 1,
    "name": "DevOps Engineering Fundamentals",
    "category": "DevOps",
    "status": "Active"
  },
  {
    "id": 2,
    "name": "Flask Web Development & API Architecture",
    "category": "Backend Development",
    "status": "Active"
  }
]""")

    doc.add_paragraph("Flask `/api` Route Handler (`app.py`):")
    add_code_block(doc, """@app.route('/api', methods=['GET'])
def get_api_data():
    try:
        with open(BACKEND_JSON_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return jsonify({
            "status": "success",
            "count": len(data),
            "data": data
        }), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500""")

    add_heading_styled(doc, "Task 1 Verification & Output Screenshot", level=2)
    add_image_safe(doc, os.path.join('screenshots', 'task1_api_response.png'), "Task 1: GET /api Route returning JSON list from backend file")

    # Section 3: Task 2 - Frontend Form with MongoDB Atlas
    add_heading_styled(doc, "3. Task 2: Frontend Form with MongoDB Atlas Integration", level=1)
    doc.add_paragraph("Requirement: Create a frontend form that inserts submitted data into MongoDB Atlas cloud database with proper success and error handling.")

    add_heading_styled(doc, "Frontend Form Interface", level=2)
    doc.add_paragraph("The frontend submission form (`index.html`) gathers Full Name, Email Address, Role, Experience, and Message. It posts to `/submit`.")
    add_image_safe(doc, os.path.join('screenshots', 'task2_frontend_form.png'), "Task 2: Frontend Form Interface (index.html)")

    add_heading_styled(doc, "Task 2 (Error Handling): Display Error on Same Page (No Redirection)", level=2)
    doc.add_paragraph("Requirement: On error, display the error on the same page without redirection.")
    doc.add_paragraph("Implementation: Server-side validation or MongoDB cluster error catches the exception and immediately renders `index.html` with an `error` parameter and status code 400/500, keeping user input preserved on the form page without performing any HTTP redirect.")

    add_code_block(doc, """# Task 2 Error Handling Code snippet in app.py
if not name or not email or not role:
    error_msg = "Validation Error: Full Name, Email Address, and Role are mandatory fields."
    # Renders index.html directly on error without redirection!
    return render_template('index.html', error=error_msg, form_data=form_data), 400""")

    add_image_safe(doc, os.path.join('screenshots', 'task2_error_on_same_page.png'), "Task 2 Error Handling: Error displayed directly on the SAME form page without redirection")

    add_heading_styled(doc, "Task 2 (Success Handling): Redirection to Success Page", level=2)
    doc.add_paragraph("Requirement: On success, the user should be redirected to another page displaying the message 'Data submitted successfully'.")
    doc.add_paragraph("Implementation: Upon successful insertion into MongoDB Atlas cloud collection (`collection.insert_one(document)`), Flask returns `redirect(url_for('success', id=inserted_id))`. The `/success` route renders `success.html` displaying the exact confirmation message.")

    add_code_block(doc, """# Task 2 Success Code snippet in app.py
result = collection.insert_one(document)
# Redirects to /success page on successful MongoDB insertion!
return redirect(url_for('success', id=str(result.inserted_id)))""")

    add_image_safe(doc, os.path.join('screenshots', 'task2_success_redirect.png'), "Task 2 Success Handling: User redirected to /success page displaying 'Data submitted successfully'")

    add_heading_styled(doc, "Stored Documents View in MongoDB Atlas", level=2)
    doc.add_paragraph("The `/records` endpoint retrieves inserted records from the MongoDB Atlas collection and displays them in a structured table format.")
    add_image_safe(doc, os.path.join('screenshots', 'task2_mongodb_records.png'), "MongoDB Atlas Stored Records View (/records)")

    # Section 4: Submission Guidelines & GitHub Link
    add_heading_styled(doc, "4. Submission Guidelines & Package Verification", level=1)
    doc.add_paragraph("All files are organised inside folder `Flask_and_MongoDB_Rohit` and compressed into `Flask_and_MongoDB_Rohit.zip` as mandated.")

    checklist_p = doc.add_paragraph()
    items = [
        "✔ Folder Name: Flask_and_MongoDB_Rohit",
        "✔ Complete Flask application source code (app.py, templates, static)",
        "✔ Backend JSON data file (data/backend_data.json)",
        "✔ Environment setup (.env, .env.example, requirements.txt)",
        "✔ Complete Documentation file with screenshots (Flask_and_MongoDB_Documentation.docx)",
        "✔ GitHub Repository Link: https://github.com/Rohit00071/TuteDude_assignmet",
        "✔ Compressed Zip File: Flask_and_MongoDB_Rohit.zip"
    ]
    for itm in items:
        p = doc.add_paragraph(itm)
        p.paragraph_format.left_indent = Inches(0.25)

    doc.save("Flask_and_MongoDB_Documentation.docx")
    print("Documentation saved successfully as 'Flask_and_MongoDB_Documentation.docx'!")

if __name__ == '__main__':
    build_docx()
